# Assets Folder — Anvi Ahuja Website

Place the following files here before deploying.
The website shows elegant placeholders automatically if any file is missing.

## 📸 Personal Photo
| File          | Size        | Notes                                      |
|---------------|-------------|--------------------------------------------|
| photo.jpg     | 500 × 600 px | Professional, warm-toned, soft background |

## 📄 Resume
| File          | Notes                                    |
|---------------|------------------------------------------|
| resume.pdf    | Keep under 2 MB. Must be text-selectable.|

## 🖼️ Project Images  (800 × 500 px each, JPG quality 80%)
| File                     | Section                       |
|--------------------------|-------------------------------|
| project-analytics.jpg    | Marketing Analytics Dashboard |
| project-brand.jpg        | Brand Strategy Analysis       |
| project-research.jpg     | Business Research             |
| project-tableau.jpg      | Tableau Dashboards            |
| project-hr.jpg           | HR Internship — Lahori Zeera  |

## 🗞️ Journal / Article Images
| File                  | Article                      | Recommended Size |
|-----------------------|------------------------------|------------------|
| journal-apple.jpg     | Why Apple Feels Premium      | 1200 × 700 px (featured, spans two columns) |
| journal-starbucks.jpg | Starbucks' Pricing Strategy  | 800 × 500 px     |
| journal-zomato.jpg    | Zomato vs Swiggy             | 800 × 500 px     |
| journal-amul.jpg      | How Amul Built Trust         | 800 × 500 px     |
| journal-nike.jpg      | Lessons from Nike Branding   | 800 × 500 px     |

## Tips
- Optimise all images at https://squoosh.app before uploading.
- For project images, a tasteful screenshot or a flat-lay mockup works well.
- For journal images, royalty-free options: Unsplash (unsplash.com) or Pexels (pexels.com).
- Use the same warm, editorial tone across all images for visual consistency.

## Adding a New Journal Article
1. Add a new image: assets/journal-yourslug.jpg
2. In index.html, find the comment "HOW TO ADD NEW ARTICLES"
3. Duplicate any <article class="journal-card"> block
4. Update: image src, data-category, reading time, title, description
That's all — the layout handles itself.
